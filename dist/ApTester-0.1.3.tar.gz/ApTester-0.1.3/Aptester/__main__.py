from . import core

core.main()
